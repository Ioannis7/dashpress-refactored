export const parameters = {
  actions: { argTypesRegex: "^on.*" },
};
