This folder is modeled exactly like the `pages` folder.

The desired state is that every file in `pages` will have a corresponding test file here