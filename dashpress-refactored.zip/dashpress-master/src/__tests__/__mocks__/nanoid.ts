export const nanoid = jest.fn();
