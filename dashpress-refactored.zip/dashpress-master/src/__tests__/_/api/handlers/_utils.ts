export const BASE_TEST_URL = (url: string) => `http://api.test.com${url}`;
