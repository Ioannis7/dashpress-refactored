export const portalApiHandlers = [];
