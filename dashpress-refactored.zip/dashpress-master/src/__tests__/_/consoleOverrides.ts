/* eslint-disable no-console */
/* eslint-disable func-names */
console.error = function () {};

// :eyes fix all warning
console.warn = function () {};

export {};
