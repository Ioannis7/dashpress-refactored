import type { ValidationImplType } from "./types";

export const anyBodyValidationImpl: ValidationImplType<void> = async () => {
  /*
    This is just to statify TS
    */
};
