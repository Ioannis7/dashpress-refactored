export type PortalValidationKeys = "anyBody";

export const PortalValidationImpl = {};
