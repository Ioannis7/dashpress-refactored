import type { ValidationImplType } from "./types";

export const guestValidationImpl: ValidationImplType<void> = async () => {
  /*
    This is just to statify TS
    */
};
