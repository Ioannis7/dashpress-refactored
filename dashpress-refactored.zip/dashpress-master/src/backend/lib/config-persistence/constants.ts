export const CONFIG_TABLE_PREFIX = (domain: string) => `dashpress__${domain}`;
