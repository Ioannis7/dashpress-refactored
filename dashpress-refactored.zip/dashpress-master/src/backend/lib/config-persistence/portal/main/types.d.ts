export type PortalConfigDomain = "";
