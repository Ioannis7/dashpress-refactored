export const createMetaData = () => {
  return {};
};

export const updateMetaData = () => {
  return {};
};
