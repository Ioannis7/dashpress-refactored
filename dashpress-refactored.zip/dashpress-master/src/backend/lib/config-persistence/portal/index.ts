export { createMetaData, updateMetaData } from "./main";
export type { PortalConfigDomain } from "./main/types";
