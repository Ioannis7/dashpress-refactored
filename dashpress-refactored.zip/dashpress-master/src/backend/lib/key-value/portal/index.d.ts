export { type PortalKeyValueDomain } from "./main";
