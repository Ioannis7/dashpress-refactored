export type PortalKeyValueDomain = "";
