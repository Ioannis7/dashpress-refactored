export enum CacheAdaptorTypes {
  Memory = "memory",
  Redis = "redis",
}
