export enum StorageIntegrations {
  S3 = "s3",
  MINIO = "minio",
  CLOUDINARY = "cloudinary",
  GOOGLE = "google",
}
