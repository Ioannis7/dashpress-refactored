export { getPortalMenuItems, portalCheckIfIsMenuAllowed } from "./main";
