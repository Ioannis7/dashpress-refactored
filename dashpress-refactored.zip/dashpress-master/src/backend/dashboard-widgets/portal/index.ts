export {
  mutateGeneratedDashboardWidgets,
  PORTAL_DASHBOARD_PERMISSION,
} from "./main";
