export { getPortalAuthenticationResponse } from "./main";
