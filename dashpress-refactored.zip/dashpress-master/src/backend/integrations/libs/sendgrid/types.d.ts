export type IActionConfig = {
  apiKey: string;
};
