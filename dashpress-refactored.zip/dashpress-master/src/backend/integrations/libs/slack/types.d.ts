export type IActionConfig = {
  token: string;
};
