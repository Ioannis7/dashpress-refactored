export type IActionConfig = {
  authToken: string;
  accountSid: string;
};
