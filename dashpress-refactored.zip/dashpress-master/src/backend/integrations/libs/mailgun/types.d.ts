export type IActionConfig = {
  apiKey: string;
  domain: string;
};
