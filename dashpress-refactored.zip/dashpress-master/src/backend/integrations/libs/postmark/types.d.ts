export type IActionConfig = {
  serverToken: string;
};
