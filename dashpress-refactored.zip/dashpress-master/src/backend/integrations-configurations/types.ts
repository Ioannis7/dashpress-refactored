export interface IGroupCredential {
  key: string;
  fields: string[];
}
