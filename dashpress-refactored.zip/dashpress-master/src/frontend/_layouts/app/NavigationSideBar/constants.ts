export const SIDE_BAR_WIDTH_VARIATIONS = {
  full: 235,
  collapsed: 55,
};

export const NAVIGATION_MENU_ENDPOINT = "/api/menu";
