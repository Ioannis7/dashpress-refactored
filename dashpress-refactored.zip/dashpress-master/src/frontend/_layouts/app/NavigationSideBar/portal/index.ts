export {
  PORTAL_SYSTEM_LINK_CONFIG_LINKS,
  useConstantNavigationMenuItems,
} from "./main";
